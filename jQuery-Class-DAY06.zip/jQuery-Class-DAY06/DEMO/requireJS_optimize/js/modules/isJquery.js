// 모듈 정의
define(['jquery'], function() {
	function isJquery () {
		return !!window.jQuery;
	}
	return isJquery;
});