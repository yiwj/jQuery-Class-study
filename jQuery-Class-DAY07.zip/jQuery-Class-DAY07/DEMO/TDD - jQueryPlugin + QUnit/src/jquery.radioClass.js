(function(global, $, undefined){
	'use strict';

	// jQuery 플러그인 코드
	if (!$.fn.radioClass) {
		$.fn.radioClass = function() {
			return this;
		};
	}

})(window, window.jQuery);