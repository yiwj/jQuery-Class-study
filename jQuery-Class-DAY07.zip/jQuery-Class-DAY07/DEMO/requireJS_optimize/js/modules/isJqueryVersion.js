// 모듈 정의
define(['jquery'], function($) {
	return $.fn.jquery;
});