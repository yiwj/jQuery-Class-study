require(['modernizr', 'detectizr'], function(m, d) {
	console.log('Modernizr: ',m, '\nDetectizr: ',d);
});