require(['init'], function(init) {
	'use strict';

	setTimeout(init, 1000);

});