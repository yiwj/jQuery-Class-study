require(['detectizr'], function(D) {
	'use strict';
	// <html> 요소의 class 속성 값에 사용자 기기의 정보를 제공한다.
	D.detect();
});