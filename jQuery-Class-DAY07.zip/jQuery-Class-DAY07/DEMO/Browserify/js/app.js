/**
 * --------------------------------
 * CommonJS 방식
 * --------------------------------
 */
// 모듈 호출
var instructor = require('./instructor.js');

console.log(instructor.name);